﻿Public Class Utama
    Private Sub Utama_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        FormBorderStyle = FormBorderStyle.None
        munculdashboard()
    End Sub
    Sub bersih()
        Me.PanelUtama.Controls.Clear()

    End Sub
    Sub munculdashboard()
        Me.PanelUtama.Controls.Clear()
        Dashboard.TopLevel = False
        Dashboard.AutoSize = False
        Dashboard.FormBorderStyle = FormBorderStyle.None
        Dashboard.Dock = DockStyle.Fill
        Me.PanelUtama.Controls.Add(Dashboard)
        Dashboard.Show()
    End Sub
    Private Sub btndashboard_Click(sender As Object, e As EventArgs) Handles btndashboard.Click
        munculdashboard()
    End Sub

    Private Sub btnminimize_Click(sender As Object, e As EventArgs) Handles btnminimize.Click
        WindowState = FormWindowState.Minimized
    End Sub

    Private Sub btnmax_Click(sender As Object, e As EventArgs) Handles btnmax.Click
        If WindowState = FormWindowState.Normal Then
            WindowState = FormWindowState.Maximized
        Else
            WindowState = FormWindowState.Normal
        End If
    End Sub

    Private Sub btnclose_Click(sender As Object, e As EventArgs) Handles btnclose.Click
        Me.Close()
        LoginPage.Close()
    End Sub

    Private Sub btnproduk_Click(sender As Object, e As EventArgs) Handles btnproduk.Click
        Me.PanelUtama.Controls.Clear()
        Produk.TopLevel = False
        Produk.AutoSize = False
        Produk.FormBorderStyle = FormBorderStyle.None
        Produk.Dock = DockStyle.Fill
        Me.PanelUtama.Controls.Add(Produk)
        Produk.Show()
    End Sub

    Private Sub btnlogout_Click(sender As Object, e As EventArgs) Handles btnlogout.Click
        Me.Visible = False

        LoginPage.Show()
    End Sub
End Class