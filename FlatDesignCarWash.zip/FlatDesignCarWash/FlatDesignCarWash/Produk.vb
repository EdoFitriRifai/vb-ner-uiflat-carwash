﻿Public Class Produk
    Dim totalbayar As Double

    Sub bersih()
        ListView1.Items.Clear()
        txttotal.Text = ""
        txtbayar.Text = ""
        txtkembalian.Text = ""
        lbljmlh.Text = ""
    End Sub
    Sub notransaksi()

    End Sub
    Sub totalharga()
        Dim total As Integer
        For i As Integer = 0 To ListView1.Items.Count - 1
            total = total + ListView1.Items(i).SubItems(5).Text
        Next
        'Tampilkan hasil dari Total Bayar
        txttotal.Text = total
    End Sub
    Sub utamamuncul()
        Me.PanelMenupilihan.Controls.Clear()
        PilihanMenu.TopLevel = False
        PilihanMenu.AutoSize = False
        PilihanMenu.FormBorderStyle = FormBorderStyle.None
        PilihanMenu.Dock = DockStyle.Fill
        Me.PanelMenupilihan.Controls.Add(PilihanMenu)
        PilihanMenu.Show()
    End Sub
    Private Sub Produk_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        FormBorderStyle = FormBorderStyle.None
        WindowState = FormWindowState.Maximized
        Call utamamuncul()

    End Sub
    Private Sub Button3_Click(sender As Object, e As EventArgs)
        Me.PanelMenupilihan.Controls.Clear()
        CuciMobil.TopLevel = False
        CuciMobil.AutoSize = False
        CuciMobil.FormBorderStyle = FormBorderStyle.None
        CuciMobil.Dock = DockStyle.Fill
        Me.PanelMenupilihan.Controls.Add(CuciMobil)
        CuciMobil.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        totalharga()
    End Sub

    Private Sub Button3_Click_1(sender As Object, e As EventArgs) Handles Button3.Click

        If Val(txtbayar.Text) < Val(txttotal.Text) Then
            MsgBox("Pembayaran Kurang!")
            txtbayar.Text = ""
            txtkembalian.Text = ""
            txtbayar.Focus()
        ElseIf Val(txtbayar.Text) = Val(txttotal.Text) Then
            txtkembalian.Text = 0
        ElseIf Val(txtbayar.Text) - Val(txttotal.Text) Then
            txtkembalian.Text = Val(txtbayar.Text) - Val(txttotal.Text)
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        bersih()
    End Sub
End Class