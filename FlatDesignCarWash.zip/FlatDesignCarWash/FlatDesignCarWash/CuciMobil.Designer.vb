﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class CuciMobil
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Panel25 = New System.Windows.Forms.Panel()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.Panel24 = New System.Windows.Forms.Panel()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Panel23 = New System.Windows.Forms.Panel()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnenter = New System.Windows.Forms.Button()
        Me.cmbjumlah = New System.Windows.Forms.ComboBox()
        Me.txtharga = New System.Windows.Forms.TextBox()
        Me.txtnama = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.tambah1 = New System.Windows.Forms.CheckBox()
        Me.tambah2 = New System.Windows.Forms.CheckBox()
        Me.tambah3 = New System.Windows.Forms.CheckBox()
        Me.Panel25.SuspendLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel24.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel23.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel25
        '
        Me.Panel25.Controls.Add(Me.Label14)
        Me.Panel25.Controls.Add(Me.Label13)
        Me.Panel25.Controls.Add(Me.PictureBox5)
        Me.Panel25.Controls.Add(Me.PictureBox6)
        Me.Panel25.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel25.Location = New System.Drawing.Point(0, 379)
        Me.Panel25.Name = "Panel25"
        Me.Panel25.Size = New System.Drawing.Size(724, 251)
        Me.Panel25.TabIndex = 8
        '
        'Label14
        '
        Me.Label14.Font = New System.Drawing.Font("Microsoft Tai Le", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(331, 220)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(220, 24)
        Me.Label14.TabIndex = 9
        Me.Label14.Text = "SUPER BUS"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label13
        '
        Me.Label13.Font = New System.Drawing.Font("Microsoft Tai Le", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(26, 220)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(220, 24)
        Me.Label13.TabIndex = 8
        Me.Label13.Text = "TRUCK"
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PictureBox5
        '
        Me.PictureBox5.Image = Global.FlatDesignCarWash.My.Resources.Resources.pngwing_com
        Me.PictureBox5.Location = New System.Drawing.Point(334, 41)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(217, 176)
        Me.PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox5.TabIndex = 7
        Me.PictureBox5.TabStop = False
        '
        'PictureBox6
        '
        Me.PictureBox6.Image = Global.FlatDesignCarWash.My.Resources.Resources.pngegg__1_
        Me.PictureBox6.Location = New System.Drawing.Point(26, 47)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(220, 170)
        Me.PictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox6.TabIndex = 6
        Me.PictureBox6.TabStop = False
        '
        'Panel24
        '
        Me.Panel24.Controls.Add(Me.Label12)
        Me.Panel24.Controls.Add(Me.Label11)
        Me.Panel24.Controls.Add(Me.PictureBox2)
        Me.Panel24.Controls.Add(Me.PictureBox1)
        Me.Panel24.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel24.Location = New System.Drawing.Point(0, 152)
        Me.Panel24.Name = "Panel24"
        Me.Panel24.Size = New System.Drawing.Size(724, 227)
        Me.Panel24.TabIndex = 7
        '
        'Label12
        '
        Me.Label12.Font = New System.Drawing.Font("Microsoft Tai Le", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(331, 186)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(220, 24)
        Me.Label12.TabIndex = 7
        Me.Label12.Text = "BUS"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label11
        '
        Me.Label11.Font = New System.Drawing.Font("Microsoft Tai Le", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(26, 186)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(220, 24)
        Me.Label11.TabIndex = 6
        Me.Label11.Text = "MINI BUS"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.FlatDesignCarWash.My.Resources.Resources.NicePng_bus_png_102524
        Me.PictureBox2.Location = New System.Drawing.Point(334, 14)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(217, 169)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 5
        Me.PictureBox2.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.FlatDesignCarWash.My.Resources.Resources.kisspng_car_foton_motor_van_minibus_foton_pampanga_5b15bcd357d9b1_8560796115281512513598
        Me.PictureBox1.Location = New System.Drawing.Point(26, 14)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(220, 169)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 4
        Me.PictureBox1.TabStop = False
        '
        'Label10
        '
        Me.Label10.Dock = System.Windows.Forms.DockStyle.Top
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 30.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(0, 73)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(724, 79)
        Me.Label10.TabIndex = 6
        Me.Label10.Text = "JENIS MOBIL"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel23
        '
        Me.Panel23.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(126, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.Panel23.Controls.Add(Me.tambah3)
        Me.Panel23.Controls.Add(Me.tambah2)
        Me.Panel23.Controls.Add(Me.tambah1)
        Me.Panel23.Controls.Add(Me.Button1)
        Me.Panel23.Controls.Add(Me.Label2)
        Me.Panel23.Controls.Add(Me.btnenter)
        Me.Panel23.Controls.Add(Me.cmbjumlah)
        Me.Panel23.Controls.Add(Me.txtharga)
        Me.Panel23.Controls.Add(Me.txtnama)
        Me.Panel23.Controls.Add(Me.Label9)
        Me.Panel23.Controls.Add(Me.Label8)
        Me.Panel23.Controls.Add(Me.Label7)
        Me.Panel23.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel23.Location = New System.Drawing.Point(0, 0)
        Me.Panel23.Name = "Panel23"
        Me.Panel23.Size = New System.Drawing.Size(724, 73)
        Me.Panel23.TabIndex = 5
        '
        'Button1
        '
        Me.Button1.FlatAppearance.BorderSize = 0
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(629, 6)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(90, 64)
        Me.Button1.TabIndex = 11
        Me.Button1.Text = "Kembali"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Tai Le", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(291, 7)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(83, 21)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "Tambahan"
        '
        'btnenter
        '
        Me.btnenter.FlatAppearance.BorderSize = 0
        Me.btnenter.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnenter.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnenter.ForeColor = System.Drawing.Color.White
        Me.btnenter.Location = New System.Drawing.Point(533, 6)
        Me.btnenter.Name = "btnenter"
        Me.btnenter.Size = New System.Drawing.Size(90, 64)
        Me.btnenter.TabIndex = 8
        Me.btnenter.Text = "Enter"
        Me.btnenter.UseVisualStyleBackColor = True
        '
        'cmbjumlah
        '
        Me.cmbjumlah.FormattingEnabled = True
        Me.cmbjumlah.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"})
        Me.cmbjumlah.Location = New System.Drawing.Point(229, 34)
        Me.cmbjumlah.Name = "cmbjumlah"
        Me.cmbjumlah.Size = New System.Drawing.Size(56, 21)
        Me.cmbjumlah.TabIndex = 7
        '
        'txtharga
        '
        Me.txtharga.Location = New System.Drawing.Point(126, 34)
        Me.txtharga.Name = "txtharga"
        Me.txtharga.ReadOnly = True
        Me.txtharga.Size = New System.Drawing.Size(96, 20)
        Me.txtharga.TabIndex = 6
        '
        'txtnama
        '
        Me.txtnama.Location = New System.Drawing.Point(15, 34)
        Me.txtnama.Name = "txtnama"
        Me.txtnama.ReadOnly = True
        Me.txtnama.Size = New System.Drawing.Size(105, 20)
        Me.txtnama.TabIndex = 5
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Tai Le", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.White
        Me.Label9.Location = New System.Drawing.Point(225, 7)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(60, 21)
        Me.Label9.TabIndex = 3
        Me.Label9.Text = "Jumlah"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Tai Le", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(122, 7)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(52, 21)
        Me.Label8.TabIndex = 2
        Me.Label8.Text = "Harga"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Tai Le", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(11, 7)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(52, 21)
        Me.Label7.TabIndex = 1
        Me.Label7.Text = "Nama"
        '
        'tambah1
        '
        Me.tambah1.AutoSize = True
        Me.tambah1.Location = New System.Drawing.Point(295, 32)
        Me.tambah1.Name = "tambah1"
        Me.tambah1.Size = New System.Drawing.Size(83, 17)
        Me.tambah1.TabIndex = 12
        Me.tambah1.Text = "Cuci Kolong"
        Me.tambah1.UseVisualStyleBackColor = True
        '
        'tambah2
        '
        Me.tambah2.AutoSize = True
        Me.tambah2.Location = New System.Drawing.Point(295, 53)
        Me.tambah2.Name = "tambah2"
        Me.tambah2.Size = New System.Drawing.Size(78, 17)
        Me.tambah2.TabIndex = 13
        Me.tambah2.Text = "Cuci Mesin"
        Me.tambah2.UseVisualStyleBackColor = True
        '
        'tambah3
        '
        Me.tambah3.AutoSize = True
        Me.tambah3.Location = New System.Drawing.Point(391, 32)
        Me.tambah3.Name = "tambah3"
        Me.tambah3.Size = New System.Drawing.Size(78, 17)
        Me.tambah3.TabIndex = 14
        Me.tambah3.Text = "Cuci Polish"
        Me.tambah3.UseVisualStyleBackColor = True
        '
        'CuciMobil
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(724, 503)
        Me.Controls.Add(Me.Panel25)
        Me.Controls.Add(Me.Panel24)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Panel23)
        Me.Name = "CuciMobil"
        Me.Text = "CuciMobil"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Panel25.ResumeLayout(False)
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel24.ResumeLayout(False)
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel23.ResumeLayout(False)
        Me.Panel23.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel25 As Panel
    Friend WithEvents Label14 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents Panel24 As Panel
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Panel23 As Panel
    Friend WithEvents Label2 As Label
    Friend WithEvents btnenter As Button
    Friend WithEvents cmbjumlah As ComboBox
    Friend WithEvents txtharga As TextBox
    Friend WithEvents txtnama As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents tambah2 As CheckBox
    Friend WithEvents tambah1 As CheckBox
    Friend WithEvents tambah3 As CheckBox
End Class
